CREATE TRIGGER [dbo].[PX_UPDATE_FIN_CategoriaCuenta] 
ON [dbo].[PX_FIN_CategoriaCuenta]
AFTER INSERT, UPDATE
   AS
    BEGIN
	DECLARE @id INT 
    SET NOCOUNT ON;  
    SELECT @id = Id from inserted

	IF (SELECT COUNT(1) FROM [PX_FIN_CategoriaCuenta] WHERE Id = @id and FechaCreacion IS NOT NULL) = 1
		UPDATE T
		SET T.FechaModificacion = GETDATE()
		FROM PX_FIN_CategoriaCuenta T
		WHERE T.Id = @id;		
    END

go

