CREATE TRIGGER [dbo].[TR_PX_SIS_Aprobaciones] ON dbo.PX_SIS_Aprobaciones
    AFTER INSERT, UPDATE
    AS
    BEGIN
	DECLARE @idCat INT  
    SET NOCOUNT ON;  
    SELECT @idCat = Id from inserted  

	IF (SELECT COUNT(1) FROM PX_SIS_Aprobaciones WHERE Id = @idCat and FechaCreacion IS NOT NULL) = 0
		UPDATE PX_SIS_Aprobaciones
		SET FechaCreacion = GETDATE()
		FROM inserted
		WHERE PX_SIS_Aprobaciones.Id = @idCat;
	  ELSE
		UPDATE PX_SIS_Aprobaciones
		SET FechaModificacion = GETDATE()
		FROM inserted
		WHERE PX_SIS_Aprobaciones.Id = @idCat;
    END
go

