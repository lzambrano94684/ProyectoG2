create  TRIGGER [dbo].[TR_PX_SIS_Perfil] ON [dbo].[PX_SIS_Perfil]
    AFTER INSERT, UPDATE
    AS
    BEGIN
	DECLARE @id INT 
    SET NOCOUNT ON;  
    SELECT @id = Id from inserted

	IF (SELECT COUNT(1) FROM PX_SIS_Perfil WHERE Id = @id and FechaCreacion IS NOT NULL) = 0
		UPDATE T
		SET T.FechaCreacion = GETDATE()
		FROM PX_SIS_Perfil T
		WHERE T.Id = @id;
	  ELSE
		UPDATE T
		SET T.FechaModificacion = GETDATE()
		FROM PX_SIS_Perfil T
		WHERE T.Id = @id;		
    END
go

