-- =============================================
-- Author:		Hugo Ibarra
-- Create date: 02/04/2020
-- Description:	Almacena SALES EXPENSES
-- =============================================
CREATE PROCEDURE [dbo].[insertSE]
	@IdPais int, @IdDistribuidor int, @IdTipoGasto int, @referencia varchar(100), 
@Anio int, @ValorTipoCambio float, @FechaDoc date, @FechaIngreso date, @FechaReconocimiento date,
@IdProducto int, @IdEstatus int, @cantidad float, @PrecioML float, @ImporteML float
AS
BEGIN
declare @IdEncabezado int;
	select @IdEncabezado = Id  from PX_SEX_EncabezadoDoc where Referencia = @referencia and IdTipoGasto =@IdTipoGasto
		and IdPais =@IdPais and FechaReconocimeinto =@FechaReconocimiento and Anio =@Anio and IdDistribuidor =@IdDistribuidor;
	if @IdEncabezado = 0 or @IdEncabezado is null
			begin
				insert into PX_SEX_EncabezadoDoc (IdPais, IdDistribuidor, IdTipoGasto, Referencia, Anio, ValorTipoMoneda, FechaDoc, FechaIngreso, FechaReconocimeinto, FechaCreacion)
				values (@IdPais, @IdDistribuidor, @IdTipoGasto, @referencia, @Anio, @ValorTipoCambio, @FechaDoc, @FechaIngreso, @FechaReconocimiento, @FechaReconocimiento);
				set @IdEncabezado = @@IDENTITY;
			end
	else 
		begin
			select Id = @IdEncabezado from PX_SEX_EncabezadoDoc where Referencia = @referencia and IdTipoGasto =@IdTipoGasto
			and IdPais =@IdPais and FechaReconocimeinto =@FechaReconocimiento and Anio =@Anio and IdDistribuidor =@IdDistribuidor;
		end
	insert into PX_SEX_DetalleDoc (IdEncabezado, IdProducto, IdEstatus, Cantidad, PrecioML, ImporteML)
	values (@IdEncabezado, @IdProducto, @IdEstatus, @cantidad, @PrecioML, @ImporteML)
	return @@IDENTITY;
END
go

