CREATE TRIGGER [dbo].[TR_PX_SIS_Catalogo] ON [dbo].[PX_SIS_Catalogo]
    AFTER INSERT, UPDATE
    AS
    BEGIN
	DECLARE @idCat INT  
    SET NOCOUNT ON;  
    SELECT @idCat = Id from inserted  

	IF (SELECT COUNT(1) FROM PX_SIS_Catalogo WHERE Id = @idCat and FechaCreacion IS NOT NULL) = 0
		UPDATE PX_SIS_Catalogo
		SET FechaCreacion = GETDATE()
		FROM inserted
		WHERE PX_SIS_Catalogo.Id = @idCat;
	  ELSE
		UPDATE PX_SIS_Catalogo
		SET FechaModificacion = GETDATE()
		FROM inserted
		WHERE PX_SIS_Catalogo.Id = @idCat;
    END
go

