CREATE PROCEDURE [dbo].[obtenerpermisos]   
    @IdModulo int,   
    @IdMenu int   
AS   

SELECT modulo.Id as Id_Modulo, modulo.Nombre as modulo,
 menu.Id as Id_Menu, menu.Nombre as menu,
 sub.Id as Id_Sub,sub.Nombre as sub_menu 
--select count(*) as cantidad_submenus
FROM PX_SIS_Modulo as modulo
INNER JOIN PX_SIS_Menu as menu ON modulo.Id = menu.IdModulo
Inner join  PX_SIS_Sub_Menu AS sub ON menu.Id = sub.IdMenu
where modulo.Id =@IdModulo and menu.Id = @IdMenu
order by modulo.Nombre asc;
go

