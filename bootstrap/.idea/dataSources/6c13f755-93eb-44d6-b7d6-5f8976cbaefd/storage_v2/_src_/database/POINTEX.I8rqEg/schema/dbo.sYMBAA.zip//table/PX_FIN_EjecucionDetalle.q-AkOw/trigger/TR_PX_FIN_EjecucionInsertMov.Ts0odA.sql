CREATE TRIGGER [dbo].[TR_PX_FIN_EjecucionInsertMov] ON dbo.PX_FIN_EjecucionDetalle
	AFTER INSERT, UPDATE, DELETE
    AS
    BEGIN
		DECLARE @idEjecucion int, @idPersona INT, @nombre varchar(50), @tipo int, @monto float, @usuarioCreacion int, @usuarioModificacion int, @montoActual float;
		SET NOCOUNT ON;
		
		SELECT @idEjecucion = IdEjecucion from inserted;
		SELECT @idPersona = IdPersona, @nombre = Codigo, @tipo = IdEjecucionTipo FROM PX_FIN_Ejecucion WHERE Id =@idEjecucion;
		SELECT @montoActual = Monto FROM PX_FIN_MovimientoCC WHERE Nombre = @nombre;
		IF @tipo = 2
			BEGIN
				SELECT @monto = SUM(Precio) FROM PX_FIN_EjecucionDetalle where IdEjecucion = @idEjecucion;
				IF NOT EXISTS(select 1 from PX_FIN_MovimientoCC where Nombre = @nombre) 
					INSERT INTO PX_FIN_MovimientoCC (IdPersona, Nombre,Tipo,Monto, Fecha, UsuarioCreacion) values (@idPersona, @nombre, 'LQCC', @monto,GETDATE(), @usuarioCreacion);
				ELSE IF @monto <> @montoActual
					UPDATE PX_FIN_MovimientoCC
					SET Monto = @monto, UsuarioModificacion = @usuarioModificacion, Fecha = GETDATE()
					where Nombre = @nombre;
			END
		IF @tipo = 4
			BEGIN
				SELECT @monto = SUM(Precio) FROM PX_FIN_EjecucionDetalle where IdEjecucion = @idEjecucion;
				IF NOT EXISTS(select 1 from PX_FIN_MovimientoFM where Nombre = @nombre) 
					INSERT INTO PX_FIN_MovimientoFM (IdPersona, Nombre,Tipo,Monto, Fecha, UsuarioCreacion) values (@idPersona, @nombre, 'LQFM', @monto,GETDATE(), @usuarioCreacion);
				ELSE IF @monto <> @montoActual
					UPDATE PX_FIN_MovimientoFM
					SET Monto = @monto, UsuarioModificacion = @usuarioModificacion, Fecha = GETDATE()
					where Nombre = @nombre;
			END
	END
go

