CREATE TRIGGER [dbo].[TR_PX_SEX_Moneda] ON [dbo].[PX_SEX_Moneda]
    AFTER INSERT, UPDATE
    AS
    BEGIN
	DECLARE @id INT
	DECLARE @valor FLOAT
	DECLARE @usuarioCreacion INT
    SET NOCOUNT ON;  
    SELECT @id = Id from inserted
	SELECT @valor = Valor from inserted
	SELECT @usuarioCreacion = UsuarioCreacion from inserted

	IF (SELECT COUNT(1) FROM PX_SEX_Moneda WHERE Id = @id and FechaCreacion IS NOT NULL) = 0
		UPDATE T
		SET T.FechaCreacion = GETDATE()
		FROM PX_SEX_Moneda T
		WHERE T.Id = @id;
	  ELSE
		UPDATE T
		SET T.FechaModificacion = GETDATE()
		FROM PX_SEX_Moneda T
		WHERE T.Id = @id;

		IF EXISTS (SELECT 1 FROM deleted)
		  SELECT @usuarioCreacion = UsuarioModificacion from inserted;
		ELSE
		  SELECT @usuarioCreacion = UsuarioCreacion from inserted;

	insert into PX_SEX_MonedaHistorico (IdMoneda, Valor, UsuarioCreacion)
	values (@id, @valor,@usuarioCreacion);

    END
go

