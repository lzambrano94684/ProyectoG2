CREATE TRIGGER [dbo].[TR_PX_SIS_CatItem] ON dbo.PX_SIS_CatItem
    AFTER INSERT, UPDATE
    AS
    BEGIN
	DECLARE @idCatItem INT  
    SET NOCOUNT ON;  
    SELECT @idCatItem = Id from inserted  

	IF (SELECT COUNT(1) FROM PX_SIS_CatItem WHERE Id = @idCatItem and FechaCreacion IS NOT NULL) = 0
		UPDATE PX_SIS_CatItem
		SET FechaCreacion = GETDATE()
		WHERE PX_SIS_CatItem.Id = @idCatItem;
	  ELSE
		UPDATE PX_SIS_CatItem
		SET FechaModificacion = GETDATE()
		WHERE PX_SIS_CatItem.Id = @idCatItem;
    END
go

