CREATE FUNCTION [dbo].[totalGastoFinancieroDistribuidores](@idEntidad varchar(100), @tipoGasto varchar(100), @anio int, @mes varchar(50),@estatus int) 
RETURNS float  
AS  
BEGIN    
    DECLARE @retval float ;   
   select @retval = SUM(dd.ImporteML) 
	from PX_SEX_EncabezadoDoc ed
	inner join PX_SEX_DetalleDoc dd on ed.Id = dd.IdEncabezado
	inner join PX_SEX_EncabezadoEstatus as enc on dd.IdEstatus = enc.Id
	inner join PX_SEX_TipoDocumento td on ed.IdTipoDoc = td.Id
	inner join PX_SEX_TipoGasto tg on ed.IdTipoGasto= tg.Id
	where YEAR(ed.FechaReconocimeinto) = @anio and MONTH(ed.FechaReconocimeinto) in(SELECT * FROM dbo.function_string_to_table(@mes, ',')) 
	and dd.IdEstatus = @estatus 
	and ed.IdTipoGasto in (select Id from PX_SEX_TipoGasto where GastoFinanciero = @tipoGasto)
	and ed.IdDistribuidor in (select Id from PX_SIS_Entidad where NombreBIXDB = @idEntidad)
    RETURN @retval
End;
go

