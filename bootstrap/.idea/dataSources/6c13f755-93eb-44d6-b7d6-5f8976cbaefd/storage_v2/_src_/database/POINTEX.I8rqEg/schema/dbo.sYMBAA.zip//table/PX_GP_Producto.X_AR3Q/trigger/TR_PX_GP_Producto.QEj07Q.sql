CREATE TRIGGER [dbo].[TR_PX_GP_Producto] 
ON dbo.PX_GP_Producto 
after INSERT, UPDATE 
AS 
  BEGIN 
      DECLARE @id          INT, 
              @IdEstatus   INT, 
              @IdUsuarioC  INT, 
              @IdUsuarioM  INT, 
              @CantEstatus INT; 

      SET nocount ON; 

      SELECT @id = id 
      FROM   inserted; 

      SELECT @IdEstatus = idestatus 
      FROM   inserted; 

      SELECT @IdUsuarioC = usuariocreacion 
      FROM   inserted; 

      SELECT @IdUsuarioM = usuariomodificacion 
      FROM   inserted; 

      SELECT @CantEstatus = (SELECT TOP 1 Count(1) 
                             FROM   px_gp_productoestatushistorial 
                             WHERE  idproducto = @id 
                                    AND idestatus = @IdEstatus); 

      IF (SELECT Count(1) 
          FROM   px_gp_producto 
          WHERE  id = @id 
                 AND fechacreacion IS NOT NULL) = 0 
        BEGIN 
            INSERT INTO px_gp_productoestatushistorial 
                        (idproducto, 
                         idestatus, 
                         usuariocreamod, 
                         accion) 
            VALUES      (@id, 
                         @IdEstatus, 
                         @IdUsuarioC, 
                         'C'); 

            UPDATE T 
            SET    T.fechacreacion = Getdate() 
            FROM   px_gp_producto T 
            WHERE  T.id = @id; 
        END 
      ELSE 
        BEGIN 
            UPDATE T 
            SET    T.fechamodificacion = Getdate() 
            FROM   px_gp_producto T 
            WHERE  T.id = @id; 

            IF ( @CantEstatus ) = 0 
              INSERT INTO px_gp_productoestatushistorial 
                          (idproducto, 
                           idestatus, 
                           usuariocreamod, 
                           accion) 
              VALUES      (@id, 
                           @IdEstatus, 
                           @IdUsuarioC, 
                           'M'); 
        END 
  END
go

