CREATE TRIGGER [dbo].[TR_PX_SIS_PerfilSubMenu] 
ON [dbo].[PX_SIS_PerfilSubMenu] 
after INSERT, UPDATE 
AS 
  BEGIN 
      DECLARE @id  INT;
            
      SET nocount ON; 

      SELECT @id = id 
      FROM   inserted; 


      IF (SELECT Count(1) 
          FROM   PX_SIS_PerfilSubMenu         WHERE  id = @id 
                 AND FechaCreacion IS NOT NULL) = 0 
        BEGIN
            UPDATE T 
            SET    T.FechaCreacion = Getdate() 
            FROM   PX_SIS_PerfilSubMenu T 
            WHERE  T.id = @id; 
        END 
      ELSE 
        BEGIN 
            UPDATE T 
            SET    T.FechaModificacion = Getdate() 
            FROM   PX_SIS_PerfilSubMenu T 
            WHERE  T.id = @id; 
        END 
  END
go

