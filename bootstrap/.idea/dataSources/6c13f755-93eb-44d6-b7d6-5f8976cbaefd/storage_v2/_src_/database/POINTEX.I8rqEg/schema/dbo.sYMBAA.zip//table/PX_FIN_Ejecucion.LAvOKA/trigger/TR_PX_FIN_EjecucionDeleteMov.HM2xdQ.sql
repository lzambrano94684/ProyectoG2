CREATE TRIGGER [dbo].[TR_PX_FIN_EjecucionDeleteMov] ON dbo.PX_FIN_Ejecucion
	AFTER DELETE
    AS
    BEGIN
		DECLARE @nombre varchar(50), @tipo int;
		SELECT @nombre = Codigo, @tipo = IdEjecucionTipo from inserted;
		print @nombre;
		DELETE FROM PX_FIN_MovimientoCC WHERE RTRIM(Nombre) = RTRIM(@nombre);
	END
go

