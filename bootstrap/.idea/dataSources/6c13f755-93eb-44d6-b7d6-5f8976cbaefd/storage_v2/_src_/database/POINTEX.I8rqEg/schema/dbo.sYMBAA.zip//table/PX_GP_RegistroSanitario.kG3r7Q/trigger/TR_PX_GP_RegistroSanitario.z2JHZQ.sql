CREATE TRIGGER [dbo].[TR_PX_GP_RegistroSanitario] 
ON dbo.PX_GP_RegistroSanitario 
after INSERT, UPDATE 
AS 
  BEGIN 
      DECLARE @id          INT, 
              @IdEstatus   INT, 
              @IdUsuarioC  INT, 
              @IdUsuarioM  INT, 
              @CantEstatus INT; 

      SET nocount ON; 

      SELECT @id = Id 
      FROM   inserted; 

      SELECT @IdEstatus = IdEstatus 
      FROM   inserted; 

      SELECT @IdUsuarioC = CONVERT(INT,UsuarioCreacion)
	  FROM   inserted; 

      SELECT @IdUsuarioM =  CONVERT(INT,UsuarioModificacion)
      FROM   inserted; 

      SELECT @CantEstatus = (SELECT TOP 1 Count(1) 
                             FROM   PX_GP_RegistroSanitarioestatushistorial 
                             WHERE  IdRegistroSanitario = @id 
                                    AND IdEstatus = @IdEstatus); 

      IF (SELECT Count(1) 
          FROM   PX_GP_RegistroSanitario 
          WHERE  Id = @id 
                 AND FechaCreacion IS NOT NULL) = 0 
        BEGIN 
            INSERT INTO PX_GP_RegistroSanitarioestatushistorial 
                        (IdRegistroSanitario, 
                         IdEstatus, 
                         UsuarioCreaMod, 
                         Accion) 
            VALUES      (@id, 
                         @IdEstatus, 
                         @IdUsuarioC, 
                         'C'); 

            UPDATE T 
            SET    T.FechaCreacion = Getdate() 
            FROM   PX_GP_RegistroSanitario T 
            WHERE  T.Id = @id; 
        END 
      ELSE 
        BEGIN 
            UPDATE T 
            SET    T.FechaModificacion = Getdate() 
            FROM   PX_GP_RegistroSanitario T 
            WHERE  T.Id = @id; 

            IF ( @CantEstatus ) = 0 
              INSERT INTO PX_GP_RegistroSanitarioestatushistorial 
                          (IdRegistroSanitario, 
                           IdEstatus, 
                           UsuarioCreaMod, 
                           Accion) 
              VALUES      (@id, 
                           @IdEstatus, 
                           @IdUsuarioC, 
                           'M'); 
        END 
  END
go

