<?php 


$txtID=(isset($_POST['txtID']))?$_POST['txtID']:"";
$txtNombre=(isset($_POST['txtNombre']))?$_POST['txtNombre']:"";
$txtEdad=(isset($_POST['txtEdad']))?$_POST['txtEdad']:"";
$txtSalario=(isset($_POST['txtSalario']))?$_POST['txtSalario']:"";
$accion=(isset($_POST['accion']))?$_POST['accion']:"";

include("../Conexion/conexion.php");

switch($accion){
    case "btnAgregar":
        $sentencia=$pdo->prepare("INSERT INTO personal(Nombre,Edad,Salario) 
        VALUES(:Nombre,:Edad,:Salario)");

        $sentencia->bindParam(':Nombre',$txtNombre);
        $sentencia->bindParam(':Edad',$txtEdad);
        $sentencia->bindParam(':Salario',$txtSalario);
        $sentencia->execute();
        echo "txtID";
        echo "Presionastes btnAgregar";
    break;

        case "btnModificar":
            $sentencia=$pdo->prepare("UPDATE personal SET 
            Nombre=:Nombre,
            Edad=:Edad,
            Salario=:Salario WHERE 
            ID=:ID"); 
           
            $sentencia->bindParam(':Nombre',$txtNombre);
            $sentencia->bindParam(':Edad',$txtEdad);
            $sentencia->bindParam(':Salario',$txtSalario);
            $sentencia->bindParam(':ID',$txtID);
            $sentencia->execute();
            header('Location: index.php');
            echo "txtID";
            echo "Presionastes btnModificar";
        break;

            case "btnEliminar":

                $sentencia=$pdo->prepare(" DELETE FROM personal  WHERE ID=:ID"); 
           
            $sentencia->bindParam(':ID',$txtID);
            $sentencia->execute();
                echo "txtID";
                echo "Presionastes btnEliminar";
            break;
                case "btnCancelar":
                    echo "txtID";   
                        echo "Presionastes btnCancelar";
                break;
}
 $sentencia=$pdo->prepare("SELECT * FROM `personal` WHERE 1");
 $sentencia->execute();
 $listaEmpleados=$sentencia->fetchAll(PDO::FETCH_ASSOC);
 print_r($listaEmpleados);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD con php u Mysql (simple) </title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"/>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" ></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>

   

<div class="container">
    <form action ="" method="post" ectype="multipart/form-data">    
    
   
    <label for="">ID:</label>
    <input type="text" name="txtID"   value="<?php echo $txtID;?>"  placeholder="" id="txtID" require="">
    <br>


    <label for="">Nombre:</label>
    <input type="text" name="txtNombre" value="<?php echo $txtNombre;?>" placeholder="" id="txtNombre" require="">
    <br>
    
    <label for="">Edad:</label>
    <input type="text" name="txtEdad" value="<?php echo $txtEdad;?>" placeholder="" id="txtEdad" require="">
    <br>

    <label for="">Salario:</label>
    <input type="text" name="txtSalario" value="<?php echo $txtSalario;?>" placeholder="" id="txtSalario" require="">
    <br>
    <button value="btnAgregar" type="submit" name="accion">Agregar</button>
    <button value="btnModificar" type="submit" name="accion">Modificar</button>
    <button value="btnEliminar" type="submit" name="accion">Eliminar</button>
    <button value="btnCancelar" type="submit" name="accion">Cancelar</button>

    </form>
    <div class="row">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Edad</th>
                <th>Salario</th>
                <th>Acciones</th>

            </tr>
        </thead>
        <?php foreach($listaEmpleados as $personal){?>
        <tr>
            <td><?php echo $personal['ID'];?></td>
            <td><?php echo $personal['Nombre'];?></td>
            <td><?php echo $personal['Edad'];?></td>
            <td><?php echo $personal['Salario'];?></td>
            <td>
            
            <form action="" method="post">
            
            


           

            <input type="hidden" name="txtID"    value="<?php  echo $personal['ID'];?>">
            <input type="hidden" name="txtNombre"  value="<?php echo $personal['Nombre'];?>">
            <input type="hidden" name="txtEdad"    value="<?php echo $personal['Edad'];?>">
            <input type="hidden" name="txtSalario" value="<?php echo $personal['Salario'];?>">
                
            <input type="submit" value="seleccionar" name="accion"> 
            <button value="btnEliminar" type="submit" name="accion">Eliminar</button>
            </td>
            </form>
           


        </tr>
        

        <?php }?>
    </table>
    </div>
</div>
    
</body>

</html>

